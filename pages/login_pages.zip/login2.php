<?php
session_start();
require("connection.php");

if ($_SERVER["REQUEST_METHOD"]=="POST") {
	$email=$_POST["email"];
	$password=$_POST["pass"];


	$sql="select * from users where email='".$email."' AND password='".$password."' ";
    //$sql="select * from sellers where email='".$email."' AND password='".$password."' ";

	$result=mysqli_query($conn,$sql);

	$row=mysqli_fetch_array($result);

	
	if($row["role_id"]=="0")
	{	
		$_SESSION["first_name"]=$firstname;
		header("location:admin.php");
	}
	if($row["role_id"]=="1")
	{	
		$_SESSION["first_name"]=$firstname;
		header("location:home.php");
	}
    if ($row["role_id"]=="2")
    {
        $_SESSION["first_name"]=$firstname;
        header("location:seller_account.php");   
     }
	else
	{
		echo "The email or password is found to be incorrect";
	}

	$_SESSION["user_id"]=$row["user_id"];
}

?>